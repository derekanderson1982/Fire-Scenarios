import React, { useState, useEffect } from "react";

export default function App() {
  const [sessionId, setSessionId] = useState(null);
  const [scenario, setScenario] = useState("");
  const [chat, setChat] = useState([]);
  const [input, setInput] = useState("");

  useEffect(() => {
    fetch("/api/session")
      .then(res => res.json())
      .then(data => {
        setSessionId(data.session_id);
        setScenario(data.scenario);
      });
  }, []);

  const sendMessage = () => {
    if (!input) return;
    fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, message: input })
    })
      .then(res => res.json())
      .then(data => {
        setChat(prev => [...prev, { user: input, bot: data.response }]);
        setInput("");
      });
  };

  const downloadReport = () => {
    fetch(`/api/report/${sessionId}`)
      .then(res => res.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `ICS_Report_${sessionId}.pdf`;
        a.click();
        window.URL.revokeObjectURL(url);
      });
  };

  return (
    <div style={{ maxWidth: 700, margin: "20px auto", fontFamily: "Arial, sans-serif" }}>
      <h2>ICS Trainer</h2>
      <p><b>Scenario:</b> {scenario || "Loading..."}</p>

      <div style={{ border: "1px solid #ccc", padding: 10, minHeight: 280, maxHeight: 320, overflowY: "auto" }}>
        {chat.map((c, i) => (
          <div key={i} style={{ marginBottom: 10 }}>
            <div><b>You:</b> {c.user}</div>
            <div><b>Bot:</b> {c.bot}</div>
            <hr />
          </div>
        ))}
      </div>

      <div style={{ marginTop: 10 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Enter your action..."
          style={{ width: "75%", padding: 6 }}
        />
        <button onClick={sendMessage} style={{ padding: "7px 12px", marginLeft: 8 }}>
          Send
        </button>
      </div>

      <div style={{ marginTop: 14 }}>
        <button onClick={downloadReport} style={{ padding: "8px 14px" }}>
          Download Report (PDF)
        </button>
      </div>
    </div>
  );
}
